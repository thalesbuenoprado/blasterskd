# Guia de Hospedagem Gratuita para o Site BlasterSKD

Este guia apresenta as melhores opções gratuitas para hospedar seu site do BlasterSKD, com instruções detalhadas para cada plataforma.

## 1. GitHub Pages

O GitHub Pages é uma excelente opção para hospedar sites estáticos gratuitamente.

### Vantagens:
- Totalmente gratuito
- Integração direta com repositórios Git
- Suporte a domínios personalizados
- HTTPS incluído
- Alta disponibilidade

### Limitações:
- Apenas para sites estáticos (sem backend)
- Limite de 1GB de armazenamento
- Limite de tráfego de 100GB/mês

### Como configurar:

1. **Crie uma conta no GitHub** (se ainda não tiver)
   - Acesse [github.com](https://github.com) e registre-se

2. **Crie um novo repositório**
   - Nome do repositório: `blasterskd` ou qualquer nome de sua preferência
   - Marque a opção "Public"
   - Inicialize com um README

3. **Prepare seu projeto para upload**
   - Certifique-se de ter feito o build do seu projeto React:
   ```bash
   cd /caminho/para/projeto_blasterskd/site_blasterskd
   pnpm run build
   ```

4. **Faça upload dos arquivos**
   - Clone o repositório localmente:
   ```bash
   git clone https://github.com/seu-usuario/blasterskd.git
   ```
   - Copie os arquivos da pasta `dist` para o repositório clonado
   - Renomeie o arquivo `index.html` para a raiz do repositório (se não estiver)
   - Adicione, comite e envie os arquivos:
   ```bash
   git add .
   git commit -m "Adicionando site BlasterSKD"
   git push origin main
   ```

5. **Configure o GitHub Pages**
   - Vá para "Settings" > "Pages"
   - Em "Source", selecione "main" como branch
   - Clique em "Save"
   - Aguarde alguns minutos para o site ser publicado

6. **Acesse seu site**
   - O URL será: `https://seu-usuario.github.io/blasterskd/`

## 2. Netlify

O Netlify é uma plataforma moderna para hospedagem de sites estáticos com recursos avançados.

### Vantagens:
- Totalmente gratuito para uso básico
- Deploy automático a partir do GitHub/GitLab/Bitbucket
- Domínios personalizados gratuitos (.netlify.app)
- HTTPS incluído
- Funções serverless gratuitas (até certo limite)
- Formulários integrados

### Limitações:
- Limite de 100GB de tráfego/mês no plano gratuito
- Limite de build minutes

### Como configurar:

1. **Crie uma conta no Netlify**
   - Acesse [netlify.com](https://netlify.com) e registre-se (pode usar sua conta GitHub)

2. **Faça deploy do seu site**
   - Opção 1: Arraste e solte a pasta `dist` do seu projeto na interface do Netlify
   - Opção 2: Conecte ao GitHub:
     - Clique em "New site from Git"
     - Selecione GitHub e autorize o Netlify
     - Selecione o repositório do seu projeto
     - Configure as opções de build:
       - Build command: `pnpm run build`
       - Publish directory: `dist`
     - Clique em "Deploy site"

3. **Configure seu domínio**
   - Por padrão, você receberá um domínio como `random-name.netlify.app`
   - Para personalizar, vá em "Site settings" > "Domain management"
   - Clique em "Options" > "Edit site name"

4. **Acesse seu site**
   - Use o link fornecido pelo Netlify

## 3. Vercel

O Vercel é uma plataforma de hospedagem focada em aplicações React, oferecendo excelente desempenho.

### Vantagens:
- Otimizado para React e outros frameworks modernos
- Integração contínua e deploy automático
- Domínios personalizados
- HTTPS incluído
- Funções serverless
- Análise de desempenho integrada

### Limitações:
- Limites de uso no plano gratuito (mas generosos)

### Como configurar:

1. **Crie uma conta no Vercel**
   - Acesse [vercel.com](https://vercel.com) e registre-se (pode usar sua conta GitHub)

2. **Importe seu projeto**
   - Clique em "New Project"
   - Importe do GitHub ou faça upload direto
   - Configure as opções de build:
     - Framework Preset: React
     - Build Command: `pnpm run build`
     - Output Directory: `dist`
   - Clique em "Deploy"

3. **Acesse seu site**
   - Use o link fornecido pelo Vercel (formato: `projeto.vercel.app`)

## 4. Cloudflare Pages

O Cloudflare Pages é uma opção mais recente, mas com excelente desempenho e limites generosos.

### Vantagens:
- Rede global CDN da Cloudflare
- Builds ilimitados
- Membros ilimitados
- 500 páginas por projeto
- Análise de Web Analytics

### Limitações:
- Interface menos intuitiva para iniciantes

### Como configurar:

1. **Crie uma conta na Cloudflare**
   - Acesse [cloudflare.com](https://cloudflare.com) e registre-se

2. **Acesse Cloudflare Pages**
   - No painel, vá para "Pages"
   - Clique em "Create a project"
   - Conecte sua conta GitHub/GitLab

3. **Configure seu projeto**
   - Selecione o repositório
   - Configure as opções de build:
     - Framework preset: Vite
     - Build command: `pnpm run build`
     - Build output directory: `dist`
   - Clique em "Save and Deploy"

4. **Acesse seu site**
   - Use o link fornecido (formato: `projeto.pages.dev`)

## 5. Render

O Render oferece hospedagem gratuita para sites estáticos com uma interface simples.

### Vantagens:
- Interface simples
- Integração com GitHub
- HTTPS incluído
- CDN global

### Limitações:
- Recursos mais limitados no plano gratuito

### Como configurar:

1. **Crie uma conta no Render**
   - Acesse [render.com](https://render.com) e registre-se

2. **Crie um novo serviço estático**
   - Clique em "New" > "Static Site"
   - Conecte ao GitHub ou faça upload direto
   - Configure as opções:
     - Build Command: `pnpm run build`
     - Publish Directory: `dist`
   - Clique em "Create Static Site"

3. **Acesse seu site**
   - Use o link fornecido pelo Render

## Recomendação Final

Para o site do BlasterSKD, recomendamos o **Netlify** ou o **Vercel** como as melhores opções gratuitas, pois oferecem:

1. Interface amigável para iniciantes
2. Excelente desempenho
3. Integração contínua automática
4. Domínios personalizados gratuitos
5. HTTPS incluído
6. Possibilidade de adicionar funções serverless no futuro

Estas plataformas permitem que você se concentre no desenvolvimento do site, sem se preocupar com a infraestrutura de hospedagem.

## Próximos Passos

Após hospedar seu site, considere:

1. Configurar um domínio personalizado
2. Adicionar Google Analytics para monitorar visitantes
3. Implementar SEO básico para melhorar a visibilidade
4. Configurar backups regulares do código-fonte
