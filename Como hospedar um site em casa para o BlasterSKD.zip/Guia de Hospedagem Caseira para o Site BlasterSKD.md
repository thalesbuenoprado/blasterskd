# Guia de Hospedagem Caseira para o Site BlasterSKD

Este guia detalhado explica como hospedar o site do BlasterSKD em sua própria casa, desde os requisitos de hardware até a configuração completa do servidor.

## 1. Requisitos de Hardware

Para hospedar um site estático como o BlasterSKD em casa, você precisará de:

### Hardware Mínimo Recomendado:
- **Computador dedicado ou servidor**: Pode ser um computador antigo ou um mini PC como Raspberry Pi 4 (4GB+ RAM)
- **Processador**: Dual-core 1.5GHz ou superior
- **Memória RAM**: 2GB ou mais
- **Armazenamento**: 32GB ou mais (SSD preferível para melhor desempenho)
- **Conexão de Internet**: Banda larga estável com pelo menos 10 Mbps de upload
- **Fonte de alimentação ininterrupta (UPS)**: Recomendado para evitar quedas de energia

### Considerações Importantes:
- O computador/servidor precisa ficar ligado 24/7 para que o site esteja sempre disponível
- Consumo de energia: considere o impacto na conta de luz
- Refrigeração adequada para funcionamento contínuo

## 2. Configuração de Rede

### Requisitos de Conexão:
- **IP Fixo**: Solicite um IP fixo ao seu provedor de internet ou configure DDNS (explicado abaixo)
- **Acesso ao roteador**: Você precisará configurar o encaminhamento de portas

### Passo a Passo:

#### 2.1. Configurar IP Estático Local
1. Acesse as configurações de rede do seu sistema operacional
2. Configure um IP estático local para o servidor (ex: 192.168.1.10)
3. Anote o endereço MAC do servidor

#### 2.2. Configurar Encaminhamento de Portas no Roteador
1. Acesse a interface de administração do seu roteador (geralmente http://192.168.1.1 ou http://192.168.0.1)
2. Localize a seção "Encaminhamento de Portas" ou "Port Forwarding"
3. Adicione uma nova regra:
   - Porta externa: 80 (HTTP) e 443 (HTTPS)
   - IP interno: o IP estático que você configurou (ex: 192.168.1.10)
   - Porta interna: 80 e 443 respectivamente

#### 2.3. Configurar DDNS (DNS Dinâmico)
Como a maioria dos provedores de internet residenciais não oferece IP fixo externo, você precisará de um serviço DDNS:

1. Crie uma conta em um serviço DDNS gratuito como No-IP (noip.com), DuckDNS (duckdns.org) ou Dynu (dynu.com)
2. Registre um nome de domínio gratuito (ex: blasterskd.ddns.net)
3. Instale o cliente DDNS no seu servidor:

```bash
# Para No-IP no Linux
sudo apt-get update
sudo apt-get install noip2
sudo noip2-setup
# Siga as instruções para configurar sua conta
```

4. Configure o cliente para iniciar automaticamente com o sistema

## 3. Instalação e Configuração do Servidor Web

Existem várias opções de servidores web, mas o Nginx é recomendado pela sua eficiência com sites estáticos.

### 3.1. Instalação do Nginx

#### No Ubuntu/Debian:
```bash
sudo apt update
sudo apt install nginx
```

#### No CentOS/RHEL:
```bash
sudo yum install epel-release
sudo yum install nginx
```

### 3.2. Configuração do Nginx para o Site BlasterSKD

1. Crie um diretório para o site:
```bash
sudo mkdir -p /var/www/blasterskd
```

2. Copie os arquivos do site para o diretório:
```bash
# Assumindo que os arquivos do site estão em ~/projeto_blasterskd/site_blasterskd/build
sudo cp -r ~/projeto_blasterskd/site_blasterskd/build/* /var/www/blasterskd/
```

3. Crie um arquivo de configuração para o site:
```bash
sudo nano /etc/nginx/sites-available/blasterskd
```

4. Adicione a seguinte configuração:
```nginx
server {
    listen 80;
    listen [::]:80;
    
    server_name seu-dominio-ddns.com www.seu-dominio-ddns.com;
    
    root /var/www/blasterskd;
    index index.html;
    
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # Configurações de cache para melhor desempenho
    location ~* \.(jpg|jpeg|png|gif|ico|css|js)$ {
        expires 1y;
        add_header Cache-Control "public, max-age=31536000";
    }
}
```

5. Crie um link simbólico para habilitar o site:
```bash
sudo ln -s /etc/nginx/sites-available/blasterskd /etc/nginx/sites-enabled/
```

6. Verifique se a configuração está correta:
```bash
sudo nginx -t
```

7. Reinicie o Nginx:
```bash
sudo systemctl restart nginx
```

### 3.3. Configuração de HTTPS com Let's Encrypt

Para adicionar segurança ao seu site com certificado SSL gratuito:

1. Instale o Certbot:
```bash
sudo apt update
sudo apt install certbot python3-certbot-nginx
```

2. Obtenha e configure o certificado:
```bash
sudo certbot --nginx -d seu-dominio-ddns.com -d www.seu-dominio-ddns.com
```

3. Siga as instruções na tela e escolha a opção para redirecionar todo o tráfego HTTP para HTTPS

4. O Certbot configurará automaticamente a renovação do certificado

## 4. Configuração de Domínio Personalizado (Opcional)

Se você preferir um domínio personalizado em vez do fornecido pelo DDNS:

1. Compre um domínio em um registrador como Namecheap, GoDaddy ou Registro.br
2. Configure os registros DNS do seu domínio:
   - Tipo: A
   - Nome: @ (ou deixe em branco)
   - Valor: Seu IP público
   - TTL: 1 hora (ou o menor disponível)
   
3. Adicione também um registro para o subdomínio www:
   - Tipo: A
   - Nome: www
   - Valor: Seu IP público
   - TTL: 1 hora

4. Atualize a configuração do Nginx para usar seu novo domínio

## 5. Procedimentos de Segurança

### 5.1. Firewall

Configure o firewall para permitir apenas o tráfego necessário:

```bash
# UFW (Ubuntu/Debian)
sudo apt install ufw
sudo ufw allow ssh
sudo ufw allow http
sudo ufw allow https
sudo ufw enable

# Firewalld (CentOS/RHEL)
sudo firewall-cmd --permanent --add-service=ssh
sudo firewall-cmd --permanent --add-service=http
sudo firewall-cmd --permanent --add-service=https
sudo firewall-cmd --reload
```

### 5.2. Atualizações Automáticas

Configure atualizações automáticas de segurança:

```bash
# Ubuntu/Debian
sudo apt install unattended-upgrades
sudo dpkg-reconfigure -plow unattended-upgrades
```

### 5.3. Fail2ban para Proteção Contra Ataques

```bash
sudo apt install fail2ban
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### 5.4. Backup Regular

Configure backups automáticos do seu site:

```bash
# Exemplo de script de backup
mkdir -p ~/backups
crontab -e
# Adicione a linha abaixo para fazer backup diário às 2 da manhã
0 2 * * * tar -czf ~/backups/blasterskd-$(date +\%Y\%m\%d).tar.gz /var/www/blasterskd
```

## 6. Manutenção do Servidor

### 6.1. Monitoramento

Instale ferramentas de monitoramento para acompanhar o desempenho:

```bash
sudo apt install htop iotop
```

Para monitoramento mais avançado, considere instalar o Netdata:

```bash
bash <(curl -Ss https://my-netdata.io/kickstart.sh)
```

### 6.2. Logs

Verifique regularmente os logs do Nginx:

```bash
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log
```

### 6.3. Atualizações do Site

Para atualizar o site quando tiver novas versões:

1. Construa a nova versão do site:
```bash
cd ~/projeto_blasterskd/site_blasterskd
pnpm run build
```

2. Faça backup da versão atual:
```bash
sudo cp -r /var/www/blasterskd /var/www/blasterskd_backup_$(date +%Y%m%d)
```

3. Copie os novos arquivos:
```bash
sudo cp -r build/* /var/www/blasterskd/
```

## 7. Solução de Problemas Comuns

### 7.1. Site não acessível externamente
- Verifique se o encaminhamento de portas está configurado corretamente
- Verifique se o firewall está permitindo tráfego nas portas 80 e 443
- Teste se o DDNS está atualizando corretamente seu IP

### 7.2. Certificado SSL expirado
- Execute manualmente a renovação:
```bash
sudo certbot renew
```

### 7.3. Servidor lento
- Verifique o uso de recursos com `htop`
- Considere otimizar a configuração do Nginx para seu hardware

## 8. Alternativas à Hospedagem Caseira

Se a hospedagem caseira se tornar complicada, considere estas alternativas:

1. **VPS (Servidor Privado Virtual)**: Provedores como DigitalOcean, Linode ou Contabo oferecem servidores a partir de $5/mês
2. **Hospedagem compartilhada**: Opções como Hostinger, Hostgator ou Locaweb são econômicas
3. **Hospedagem gratuita para sites estáticos**: Netlify, Vercel ou GitHub Pages

## Conclusão

Hospedar o site do BlasterSKD em casa é viável e pode ser uma solução econômica a longo prazo. No entanto, requer dedicação para manutenção e monitoramento constantes. Siga este guia passo a passo para garantir que seu site esteja sempre disponível e seguro.

Para qualquer dúvida adicional ou suporte, entre em contato através do formulário no próprio site do BlasterSKD.
